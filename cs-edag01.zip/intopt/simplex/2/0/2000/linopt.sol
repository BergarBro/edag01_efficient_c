z = inf
