z = nan
